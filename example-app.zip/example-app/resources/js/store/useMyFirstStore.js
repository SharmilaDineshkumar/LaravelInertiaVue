import {defineStore } from 'pinia';
import {ref} from "vue";
export const useMyFirstStore = defineStore('useMyFirstStore', () => {
    const activePage = ref('about')

    return {
        activePage
    }
})
