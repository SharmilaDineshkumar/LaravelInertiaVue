<template>
    <div>
        <h1>About Us</h1>
        <p>This is the Contact page.</p>
        <Link href="/" @click="useMyFirstStore.activePage='about'">Go to About page</Link>
    </div>
</template>

<script setup>
import BaseTemplate from "@/Layout/BaseTemplate.vue";
import {Link} from "@inertiajs/vue3";
import {useMyFirstStore} from "@/store/useMyFirstStore.js";

defineOptions({
    layout: BaseTemplate
})
</script>
