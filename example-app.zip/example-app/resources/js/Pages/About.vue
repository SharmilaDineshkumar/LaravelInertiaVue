<script setup>
import { Link } from '@inertiajs/vue3'
import BaseTemplate from "@/Layout/BaseTemplate.vue";
import {useMyFirstStore} from "@/store/useMyFirstStore.js";

defineOptions({
    layout: BaseTemplate
})
</script>

<template>
        <div>
        <p>This is the About page.</p>
        <Link href="/contact" @click="useMyFirstStore.activePage='contact'">Go to Contact</Link>
        </div>
</template>


