<template>
    <div>
        My header here
    </div>
    <div><pre>
        <Link href="/" :class="useMyFirstStore.activePage == 'about' ? 'text-danger' : 'text-primary'" @click="useMyFirstStore.activePage='about'">About</Link>
        <Link href="/contact" :class="useMyFirstStore.activePage == 'contact' ? 'text-danger' : 'text-primary'" @click="useMyFirstStore.activePage='contact'">Contact</Link>
        </pre>
        <slot/>
    </div>
    <div>
        My footer here
    </div>
</template>

<script setup>
import {Link} from "@inertiajs/vue3";
import {useMyFirstStore} from "@/store/useMyFirstStore.js";
</script>
